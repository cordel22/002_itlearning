<?php

function vek(string $datumNarodenia): int {
    // 1. zo zadaneho datumu vyparsuj objekt typu DateTime
    $datumNar = DateTime::createFromFormat('j.n.Y', $datumNarodenia);
    // ak sa nepodarilo zo zadaneho datumu vytvorit objekt DateTime (lebo bol v zlom formate)
    if ($datumNar === false) {
        return 0; // vrat, ze ma 0 rokov.
    }
    // 2. vypocitaj rozdiel dvoch datumov (toho z kroku 1 a dnesneho datumu) v rokoch
    $rozdiel = $datumNar->diff(new DateTime());
    // 3. vrat pocet rokov ako int
    return (int) $rozdiel->format('%y');
}

    $carousel = [
        [
            'obrazok' => 'obrazky/01.jpg',
            'nadpis' => 'Prvy obrazok',
            'podnadpis' => 'nejaky text',
            'text_tlacitka' => 'Klikni sem',
            'link' => 'https://www.itlearning.sk',
        ]
    ];
?>
<!-- fotografie na vrchu stranky zaciatok -->
<div class="carousel slide carousel-fade carousel-dark" data-bs-ride="carousel" id="galeria1">
            <div class="carousel-indicators">
                <button type="button" class="active" data-bs-slide-to="0" data-bs-target="#galeria1"></button>
                <button type="button" data-bs-slide-to="1" data-bs-target="#galeria1"></button>
                <button type="button" data-bs-slide-to="2" data-bs-target="#galeria1"></button>
            </div>
            <div class="carousel-inner">
                <?php 
                $active = true;
                foreach ($carousel as $c) { ?>
                <div class="carousel-item<?php if ($active) { echo ' active'; $active = false; } ?>">
                    <a href="<?= $c['link']; ?>" target="_blank">
                        <img src="<?= $c['obrazok']; ?>" alt="" class="d-block w-100">
                    </a>
                    <div class="carousel-caption d-none d-md-block" style="background-color: rgba(255, 255, 255, 0.7);">
                        <h5><?= $c['nadpis']; ?></h5>
                        <p><?= $c['podnadpis']; ?></p>
                        <div class="text-center">
                            <a href="<?= $c['link']; ?>" target="_blank" class="btn btn-primary"><?= $c['text_tlacitka']; ?></a>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-slide="prev" data-bs-target="#galeria1">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-slide="next" data-bs-target="#galeria1">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
        <!-- fotografie na vrchu stranky koniec -->

        <!-- hlavna cast stranky zaciatok -->
        <div class="container">
            <h1 class="display-6">Vitajte na tejto stránke</h1>
            <div class="row align-items-end mb-4">

                <div class="col-md-3">
                    <div class="card">
                        <img src="https://image.shutterstock.com/image-photo/tender-son-kisses-happy-mother-600w-1922681069.jpg" alt="" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Produkt 1</h5>
                            <p class="card-text">
                                Toto je kratky popis produktu 1, ktory je nas najoblubenejsi. Toto je kratky popis produktu 1, ktory je nas najoblubenejsi.
                            </p>
                            <a href="#" class="btn btn-primary"><i class="bi bi-zoom-in"></i> Detail</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card">
                        <img src="https://image.shutterstock.com/image-photo/new-year-2021-start-straight-600w-1843332130.jpg" alt="" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Produkt 2</h5>
                            <p class="card-text">
                                Toto je kratky popis produktu 2, ktory je nas najoblubenejsi. Toto je kratky popis produktu 2, ktory je nas najoblubenejsi.
                            </p>
                            <a href="#" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card">
                        <img src="https://image.shutterstock.com/image-photo/over-shoulder-view-female-worker-600w-1938542422.jpg" alt="" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Produkt 3</h5>
                            <p class="card-text">
                                Toto je kratky popis produktu 3, ktory je nas najoblubenejsi. Toto je kratky popis produktu 3, ktory je nas najoblubenejsi.
                            </p>
                            <a href="#" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card">
                        <img src="https://image.shutterstock.com/image-photo/portrait-young-smiling-woman-looking-600w-1865153395.jpg" alt="" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Produkt 4</h5>
                            <p class="card-text">
                                Toto je kratky popis produktu 4, ktory je nas najoblubenejsi. Toto je kratky popis produktu 4, ktory je nas najoblubenejsi.
                            </p>
                            <a href="#" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div>

            </div>

            <!-- tabulka s kontaktami zaciatok -->
            <div class="table-responsive">
                <table class="table table-hover table-bordered table-sm">
                    <thead class="table-dark">
                        <tr>
                            <th>Meno</th>
                            <th>Priezvisko</th>
                            <th>Pohlavie</th>
                            <th>Datum narodenia</th>
                            <th>Vek</th>
                            <th>Kraj</th>
                        </tr>
                    </thead>
                    <?php
                        $ludia = fopen(__DIR__ . '/../subory/ludia.txt', 'r');
                    ?>
                    <tbody>
                        <?php
                        $celkom = 0;
                            while ($riadok = fgets($ludia)) {
                                if (trim($riadok) === '') { // trim($riadok) odstran krajne biele znaky (medzera, tabulator, enter) z $riadok (zo zaciatku aj z konca)
                                    continue; // skoc na podmienku
                                }
                                $clovek = explode(';', $riadok);
                                if (count($clovek) !== 5) {
                                    continue;
                                }
                                $celkom++;
                                ?>
                                <tr>
                                    <td><?= $clovek[0]; ?></td>
                                    <td><?= $clovek[1]; ?></td>
                                    <td><i class="bi bi-gender-<?= strtoupper($clovek[2]) === 'M' ? 'male' : (strtoupper($clovek[2]) === 'Z' ? 'female' : 'ambiguous'); ?>"></i></td>
                                    <td><?= $clovek[3]; ?></td>
                                    <td><?= vek($clovek[3]); ?></td>
                                    <td><?= $clovek[4]; ?></td>
                                </tr>
                                <?php
                            }
                            fclose($ludia);
                        ?>
                    </tbody>
                    <tfoot class="table-info">
                        <tr>
                            <th colspan="4">Celkom:</th>
                            <th><?= $celkom; ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!-- tabulka s kontaktami koniec -->

            <!-- hra kocky zaciatok -->
            <div class="text-center">
                <a href="?stranka=home&hod=ano" class="btn btn-primary btn-lg">Hodiť kockami</a><br>
                <?php
                    if (isset($_GET['hod']) && $_GET['hod'] == 'ano')  {
                        for ($i=0; $i < 6; $i++) {
                            $kocka = rand(1, 6);
                            echo '<i class="bi bi-dice-' . $kocka . ' display-5"></i> ';
                        }
                    }
                ?>
            </div>
            <!-- hra kocky koniec -->
        </div>
        <!-- hlavna cast stranky koniec -->